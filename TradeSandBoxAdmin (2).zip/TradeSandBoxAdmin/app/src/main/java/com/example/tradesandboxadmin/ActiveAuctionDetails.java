package com.example.tradesandboxadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ActiveAuctionDetails extends AppCompatActivity {

    Button submit,close;
    TextView item, quantity, quality;
    LoanDetails queryValues;
    LoanDetails qv;
    String auction_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_auction_details);

        submit = findViewById(R.id.submitButton);
        submit.setEnabled(true);

        close = findViewById(R.id.closeButton);
        item = findViewById(R.id.txtitem);
        quantity = findViewById(R.id.txtqty);
        quality = findViewById(R.id.txtquality);
        queryValues = new LoanDetails();

        //Get auction ID and load auction details
        Intent intent = getIntent();
        qv = (LoanDetails)intent.getParcelableExtra("query_values");
        auction_id = qv.get("auction_id");

        String client_id = ((GlobalVars) getApplicationContext()).get_client_id();
        queryValues.push("auction_id", auction_id);
        queryValues.push("client_id", client_id);

        RetrieveAuction ret = new RetrieveAuction();
        ret.execute(queryValues);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                queryValues.push("auction_id", auction_id);

                CloseAuction cl = new CloseAuction();
                cl.execute(queryValues);
            }
        });


    }
    public void submitBtn(View view) {
        Intent i = new Intent(ActiveAuctionDetails.this, ActiveAuctionDetails.class);
        i.putExtra("query_values", queryValues);
        startActivity(i);
    }

    class RetrieveAuction extends AsyncTask<LoanDetails, String, LoanDetails> {

        // Progress dialog
        private ProgressDialog pDialog;
        JSONParser jParser = new JSONParser();

        String server_id = ((GlobalVars) getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars) getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/retrieve_auction.php";
        String message;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(ActiveAuctionDetails.this);
            pDialog.setMessage("Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if user exists. If not, adds user details and returns userID.
        // Else returns -1
        protected LoanDetails doInBackground(LoanDetails... qval) {

            int success = 0;
            LoanDetails auct_details = new LoanDetails();

            try {

                JSONObject json;

                // Send LoanDetails object to JSON parser
                if (protocol.equals("https")) {
                    json = jParser.makeHttpsRequest(url_db_item, "POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                } else {
                    json = jParser.makeHttpRequest(url_db_item, "POST", qval[0].getValues());
                }

                //Success value is always returned. Push to array before checking any other
                //values in case any exceptions are thrown for other 'null' values
                success = Integer.parseInt(json.getString("success"));

                //Check other values if success is not -1 (i.e. no exception thrown)
                if(success != -1) {
                    message = json.getString("message");

                    auct_details.push("success", Integer.toString(success));
                    auct_details.push("message", message);
                    auct_details.push("produce_type", json.getString("produce_type"));
                    auct_details.push("produce_qty", json.getString("produce_qty"));
                    auct_details.push("produce_quality", json.getString("produce_quality"));
                    auct_details.push("bid_submitted", json.getString("bid_submitted"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }

            return auct_details;
        }

        protected void onPostExecute(LoanDetails qval) {

            int success = Integer.valueOf(qval.getValues().get("success"));

            if (success == -1) {
                Toast toast = Toast.makeText(getBaseContext(), "Server connection error.", Toast.LENGTH_LONG);

                View toastView = toast.getView();
                toastView.setBackgroundResource(R.drawable.toast);
                toast.show();

                pDialog.dismiss();

            } else {
                String message = qval.getValues().get("message");
                if (success == 1) {
                    pDialog.dismiss();

                    item.setText(qval.get("produce_type"));
                    quantity.setText(qval.get("produce_qty"));
                    quality.setText(qval.get("produce_quality"));

                    int bid_submitted = Integer.parseInt(qval.get("bid_submitted"));

                    if(bid_submitted == 1){
                        submit.setEnabled(false);
                        submit.setBackgroundResource(R.drawable.disabled);
                    }
                } else {
                    Toast toast = Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG);

                    View toastView = toast.getView();
                    toastView.setBackgroundResource(R.drawable.toast);
                    toast.show();

                    pDialog.dismiss();
                }
            }
        }
    }

    class CloseAuction extends AsyncTask<LoanDetails, String, LoanDetails> {

        // Progress dialog
        private ProgressDialog pDialog;
        JSONParser jParser = new JSONParser();

        String server_id = ((GlobalVars) getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars) getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/close_auction.php";
        String message;

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(ActiveAuctionDetails.this);
            pDialog.setMessage("Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if user exists. If not, adds user details and returns userID.
        // Else returns -1
        protected LoanDetails doInBackground(LoanDetails... qval) {

            int success = 0;
            String message;

            try {

                JSONObject json;

                // Send LoanDetails object to JSON parser
                if (protocol.equals("https")) {
                    json = jParser.makeHttpsRequest(url_db_item, "POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                } else {
                    json = jParser.makeHttpRequest(url_db_item, "POST", qval[0].getValues());
                }

                //Success value is always returned. Push to array before checking any other
                //values in case any exceptions are thrown for other 'null' values
                success = Integer.parseInt(json.getString("success"));
                qval[0].push("success", Integer.toString(success));

                //Check other values if success is not -1 (i.e. no exception thrown)
                if(success != -1) {
                    qval[0].push("message", json.getString("message"));
                    qval[0].push("username", json.getString("username"));
                    qval[0].push("winning_bid", json.getString("winning_bid"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }

            return qval[0];
        }

        protected void onPostExecute(LoanDetails qval) {

            int success = Integer.valueOf(qval.getValues().get("success"));

            if (success == -1) {
                Toast toast = Toast.makeText(getBaseContext(), "Server connection error.", Toast.LENGTH_LONG);

                View toastView = toast.getView();
                toastView.setBackgroundResource(R.drawable.toast);
                toast.show();
                pDialog.dismiss();

            } else {
                String winner = "Auction winner: "+qval.get("username")+ ". Winning bid: "+qval.get("winning_bid");
                String message = qval.get("message");

                //display both the auction winner and auction successfully closed toast message

                if (success == 1) {

                    Toast toast = Toast.makeText(getBaseContext(),winner,Toast.LENGTH_LONG);
                    View toastView = toast.getView();
                    toastView.setBackgroundResource(R.drawable.toast);
                    toast.show();
                    try{
                        Thread.sleep(2000);
                    }catch(Exception e){

                    }
                    Toast toast1 = Toast.makeText(getBaseContext(),"Auction Successfully Closed.",Toast.LENGTH_LONG);

                    View toastView1 = toast1.getView();
                    toastView1.setBackgroundResource(R.drawable.toast);
                    toast1.show();

//                    Toast.makeText(getBaseContext(), winner , Toast.LENGTH_LONG).show();
//                    pDialog.dismiss();

//                    Toast.makeText(getBaseContext(), "Auction Successfully Closed", Toast.LENGTH_LONG).show();
//                    pDialog.dismiss();

                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);

                } else {

                    Toast toast = Toast.makeText(getBaseContext(), "Auction closing error.", Toast.LENGTH_LONG);

                    View toastView = toast.getView();
                    toastView.setBackgroundResource(R.drawable.toast);
                    toast.show();
                    pDialog.dismiss();
                }
            }

//            if (_auction_id == null){
//                Toast toast = Toast.makeText(getBaseContext(), "Please insert auction ID.", Toast.LENGTH_LONG);
//
//                View toastView = toast.getView();
//                toastView.setBackgroundResource(R.drawable.toast);
//                toast.show();
//                pDialog.dismiss();
//            }
        }
    }
}

