package com.example.tradesandboxadmin;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import android.content.Context;
import android.util.Log;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManagerFactory;

public class JSONParser {

    static InputStream is = null;
    static JSONObject jObj = null;
    static String json = "";

    // constructor
    public JSONParser() {

    }

    // function get json from url
    // by making HTTP POST or GET method
    public JSONObject makeHttpRequest(String str_url, String method, HashMap<String, String> params) {

        String response = "";
        Log.d("Protocol", "HTTP");
        Log.i("PHP script", "Running script: " + str_url);

        // Making HTTP request
        try {

            // check for request method
            if (method == "POST") {
                // request method is POST

                URL url = new URL(str_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod(method);
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

                Log.d("Input", getPostDataString(params));
                writer.write(getPostDataString(params));
                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    String line;
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    while ((line = br.readLine()) != null) {
                        response += line;
                    }
                }
                conn.disconnect();
            } else if (method == "GET") {


                String str_params = getPostDataString(params);
                str_url = str_url + "?" + str_params;
                URL url = new URL(str_url);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setRequestMethod(method);
                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    String line;
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    while ((line = br.readLine()) != null) {
                        response += line;
                    }
                }
                conn.disconnect();
            }

        } catch (UnsupportedEncodingException e) {
            Log.e("err", "Error: encodingexception");
            e.printStackTrace();
        } catch (IOException e) {
            Log.e("err", "Error: IOexception");
            e.printStackTrace();
        }

        // try parse the string to a JSON object
        try {
            // Print JSON response to log - useful for debugging
            Log.d("JSON response: ", response);
            jObj = new JSONObject(response);

        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e.toString());

            try {
                jObj = new JSONObject();
                jObj.put("success", Integer.valueOf(0));
                jObj.put("message", "fail");
            } catch (JSONException ev) {
            }
        }

        // return JSON String
        return jObj;
    }

    // function get json from url
    // by making HTTPS POST or GET method
    public JSONObject makeHttpsRequest(String str_url, String method, HashMap<String, String> params,
                                       Context context, final String server_id) {

        String response = "";
        Log.d("Protocol", "HTTPS");
        Log.i("PHP script", "Running script: " + str_url);
        int error_flag = 0;

        try {
            // Load CA from an InputStream
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            InputStream caInput = new BufferedInputStream(context.getAssets().open("apache.crt"));

            Certificate ca;
            ca = cf.generateCertificate(caInput);
            caInput.close();

            // Create a KeyStore containing our trusted CAs
            String keyStoreType = KeyStore.getDefaultType();
            KeyStore keyStore = KeyStore.getInstance(keyStoreType);
            keyStore.load(null, null);
            keyStore.setCertificateEntry("ca", ca);

            // Create a TrustManager that trusts the CAs in our KeyStore
            String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
            tmf.init(keyStore);

            // Create an SSLContext that uses our TrustManager
            SSLContext sslcontext = SSLContext.getInstance("TLS");
            sslcontext.init(null, tmf.getTrustManagers(), null);


            HostnameVerifier hostnameVerifier = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {

                    boolean verified = false;

                    Log.i("Verification:", "Approving hostname: "+hostname);

                    if(hostname.equals(session.getPeerHost())){
                        verified = true;
                    }

                    return verified;
                    //HostnameVerifier hv = HttpsURLConnection.getDefaultHostnameVerifier();
                    //return hv.verify(server_id, session);
                }
            };

            // Making HTTPS request

            // check for request method
            if (method == "POST") {
                // request method is POST

                URL url = new URL(str_url);
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                conn.setHostnameVerifier(hostnameVerifier);
                conn.setSSLSocketFactory(sslcontext.getSocketFactory());

                conn.setRequestMethod(method);
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

                Log.d("Input", getPostDataString(params));
                writer.write(getPostDataString(params));
                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    String line;
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    while ((line = br.readLine()) != null) {
                        response += line;
                    }
                }
                conn.disconnect();
            } else if (method == "GET") {


                String str_params = getPostDataString(params);
                str_url = str_url + "?" + str_params;
                URL url = new URL(str_url);

                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

                conn.setSSLSocketFactory(sslcontext.getSocketFactory());
                conn.setRequestMethod(method);
                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    String line;
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    while ((line = br.readLine()) != null) {
                        response += line;
                    }
                }
                conn.disconnect();
            }

            // try parse the string to a JSON object
            // Print JSON response to log - useful for debugging
            Log.d("JSON raw response: ", response);

            //To ensure other output is not converted to JSON, search for curly brackets
            response = response.substring(response.indexOf('{'));

            Log.d("JSON substr response: ", response);

            jObj = new JSONObject(response);

        } catch (Exception e) {
            Log.d("ERROR", e.toString());
            error_flag = 1;
        }

        //Populate return object if error
        if(error_flag == 1){
            try {
                jObj = new JSONObject();
                jObj.put("success", Integer.valueOf(-1));
                jObj.put("message", "fail");
            } catch (JSONException ev) {
            }
        }

        // return JSON String
        return jObj;
    }

    private static String getPostDataString(HashMap<String,String> params) throws UnsupportedEncodingException {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        for(Map.Entry<String,String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

}


