package com.example.tradesandboxadmin;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class InputAuctionDetailsActivity extends AppCompatActivity {

    Button _btn_next;
    EditText _auction_start_date;
    EditText _auction_start_time;
    EditText _auction_end_date;
    EditText _auction_end_time;
    Spinner _active;
    LoanDetails queryValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_auction_details);

        _btn_next =findViewById(R.id.nextButton);
        _auction_start_date = (EditText)findViewById(R.id.auction_start_date);
        _auction_start_time = (EditText)findViewById(R.id.auction_start_time);
        _auction_end_date = (EditText)findViewById(R.id.auction_end_date);
        _auction_end_time = (EditText)findViewById(R.id.auction_end_time);
        _active = (Spinner)findViewById(R.id.auction_active);
        queryValues = new LoanDetails();

        _auction_start_date.setInputType(InputType.TYPE_NULL);
        _auction_start_time.setInputType(InputType.TYPE_NULL);
        _auction_end_date.setInputType(InputType.TYPE_NULL);
        _auction_end_time.setInputType(InputType.TYPE_NULL);

        _auction_start_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //initialize calendar
                Calendar calendar = Calendar.getInstance();
                //get year
                final int year = calendar.get(Calendar.YEAR);
                final int month = calendar.get(Calendar.MONTH);
                final int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        InputAuctionDetailsActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        //store date in string
                        String sDate = dayOfMonth + "/" + month + "/" + year;
//                        //set date on textview
                        _auction_start_date.setText(sDate);
                    }
                },year,month,day
                );

                //disable past date
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis()-1000);

                //date picker dialog
                datePickerDialog.show();

            }

        });

        _auction_start_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimeDialog(_auction_start_time);
            }
        });

        _auction_end_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //initialize datepicker dialog
                //initialize calendar
                final Calendar calendar = Calendar.getInstance();
                //get year
                final int year = calendar.get(Calendar.YEAR);
                final int month = calendar.get(Calendar.MONTH);
                final int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        InputAuctionDetailsActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        //store date in string
                        String sDate = year + "/" + month + "/" + dayOfMonth;

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
                        _auction_end_date.setText(simpleDateFormat.format(calendar.getTime()));
//                        //set date on textview
                        _auction_end_date.setText(sDate);
                    }
                },year,month,day
                );
                //disable past date
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis()-1000);

                //date picker dialog
                datePickerDialog.show();
            }
        });

        _auction_end_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimeDialog(_auction_end_time);
            }
        });

        _btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //queryValues.push("auction_date", _auction_date.getText().toString().trim());
                queryValues.push("date_start", _auction_start_date.getText().toString().trim());
                queryValues.push("time_start", _auction_start_time.getText().toString().trim());
                queryValues.push("date_end", _auction_end_date.getText().toString().trim());
                queryValues.push("time_end", _auction_end_time.getText().toString().trim());
                queryValues.push("is_active", _active.getSelectedItem().toString().trim());

                Intent i = new Intent(InputAuctionDetailsActivity.this, AddAuctionActivity.class);
                //pass auction info
                i.putExtra("query_values", queryValues);
                startActivity(i);

            }
        });
    }

    private void showTimeDialog(final EditText time_in) {
        final Calendar calendar=Calendar.getInstance();

        TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                calendar.set(Calendar.MINUTE,minute);
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("HH:mm");
                time_in.setText(simpleDateFormat.format(calendar.getTime()));
            }
        };

        new TimePickerDialog(InputAuctionDetailsActivity.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
    }

//    private void showDateDialog(final EditText date_in) {
//        final Calendar calendar=Calendar.getInstance();
//        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
//                calendar.set(Calendar.YEAR,year);
//                calendar.set(Calendar.MONTH,month);
//                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
//                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd");
//                date_in.setText(simpleDateFormat.format(calendar.getTime()));
//            }
//        };
//        new DatePickerDialog(InputAuctionDetailsActivity.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
//    }
}
