package com.example.tradesandboxadmin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class AddAuctionActivity extends AppCompatActivity {

    Button _btn_add;
    EditText _produce_type;
    EditText _produce_quantity;
    Spinner _produce_quality;
    Spinner _status;
    LoanDetails queryValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_auction);

        _btn_add =findViewById(R.id.addButton);
        _produce_type = (EditText)findViewById(R.id.prod_type);
        _produce_quantity = (EditText) findViewById(R.id.prod_qty);
        _status = (Spinner) findViewById(R.id.auction_status);
        _produce_quality = (Spinner) findViewById(R.id.prod_qly);

        Intent intent = getIntent();
        queryValues = (LoanDetails)intent.getParcelableExtra("query_values");


        _btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                queryValues.push("produce_type", _produce_type.getText().toString().trim());
                queryValues.push("produce_qly", _produce_quality.getSelectedItem().toString().trim());
                queryValues.push("produce_qty", _produce_quantity.getText().toString().trim());
                queryValues.push("status", _status.getSelectedItem().toString().trim());
                AddAuction add = new AddAuction();
                add.execute(queryValues);

            }
        });
    }

    class AddAuction extends AsyncTask<LoanDetails, String, LoanDetails> {

        // Progress dialog
        private ProgressDialog pDialog;
        JSONParser jParser = new JSONParser();

        String server_id = ((GlobalVars) getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars) getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars) getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol + "://" + server_id + "/" + cur_folder + "/add_auction.php";
        String message;

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(AddAuctionActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if user exists. If not, adds user details and returns userID.
        // Else returns -1
        protected LoanDetails doInBackground(LoanDetails... qval) {

            int success = 0;
            try {

                JSONObject json;

                // Send LoanDetails object to JSON parser
                if (protocol.equals("https")) {
                    json = jParser.makeHttpsRequest(url_db_item, "POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                } else {
                    json = jParser.makeHttpRequest(url_db_item, "POST", qval[0].getValues());
                }

                //Success value is always returned. Push to array before checking any other
                //values in case any exceptions are thrown for other 'null' values
                success = Integer.parseInt(json.getString("success"));
                qval[0].push("success", Integer.toString(success));

                //Check other values if success is not -1 (i.e. no exception thrown)
                if (success != -1) {
                    message = json.getString("message");
                    qval[0].push("message", message);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }

            return qval[0];
        }

        protected void onPostExecute(LoanDetails qval) {

            int success = Integer.valueOf(qval.getValues().get("success"));


            if (success == -1) {
                Toast toast = Toast.makeText(getBaseContext(), "Server connection error.", Toast.LENGTH_LONG);

                View toastView = toast.getView();
                toastView.setBackgroundResource(R.drawable.toast);
                toast.show();
                pDialog.dismiss();

            } else {
                String message = qval.getValues().get("message");
                if (success == 1) {
                    Toast toast = Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG);

                    View toastView = toast.getView();
                    toastView.setBackgroundResource(R.drawable.toast);
                    toast.show();
                    pDialog.dismiss();

                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast toast = Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG);

                    View toastView = toast.getView();
                    toastView.setBackgroundResource(R.drawable.toast);
                    toast.show();
                    pDialog.dismiss();
                }
            }

        }
    }
}
