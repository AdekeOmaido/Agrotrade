package com.example.tradesandboxadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button _btn_add_auction;
    Button _btn_close_auction;
    Button _btn_active_request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _btn_add_auction =findViewById(R.id.addAuctionButton);
        _btn_close_auction =findViewById(R.id.closeAuctionButton);
        _btn_active_request =findViewById(R.id.activeTransRequestButton);

        _btn_add_auction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), InputAuctionDetailsActivity.class);
                startActivity(intent);
            }
        });

        _btn_close_auction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(), ActiveAuctionList.class);
                startActivity(intent);
            }
        });

        _btn_active_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ActiveRequests.class);
                startActivity(intent);
            }
        });

    }
}