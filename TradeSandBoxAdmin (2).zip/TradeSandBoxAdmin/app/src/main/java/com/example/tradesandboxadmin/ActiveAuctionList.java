package com.example.tradesandboxadmin;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ActiveAuctionList extends AppCompatActivity {

    ListView myListView;
    ArrayAdapter<Auction> adapter;
    ArrayAdapter<Auction>dbAdapter;
    ArrayList<Auction> data;

    LoanDetails queryValues;
    int auct_selected;
    String Status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_auction_list);

        data = new ArrayList<>();
        queryValues = new LoanDetails();
        dbAdapter = new ArrayAdapter<Auction>(this, android.R.layout.simple_list_item_1, data);

        myListView = findViewById(R.id.myListView);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long itemID) {

                Auction dt = (Auction)adapterView.getItemAtPosition(position);
                auct_selected = dt.getAuctId();

                Log.d("Selected auction: ",Integer.toString(auct_selected));

                queryValues.push("auction_id", Integer.toString(auct_selected));

                Intent intent = new Intent(ActiveAuctionList.this, ActiveAuctionDetails.class);
                intent.putExtra("query_values", queryValues);
                startActivity(intent);
            }
        });

        getAuctions(data);

    }
    //populate arraylist
    public void getAuctions(ArrayList<Auction> data){
        //data.clear();
        try{

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            //Check internet connection
            Context context = getApplicationContext();
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            if (activeNetwork != null) {
                //connected to the internet
                GetAuctionDetails getAuctionDetails = new GetAuctionDetails();
                getAuctionDetails.execute(data);
            } else {
                // not connected to the internet
                Toast.makeText(getBaseContext(), "Internet connection unavailable.", Toast.LENGTH_LONG).show();
            }

        }catch(NullPointerException e){
            e.printStackTrace();
        }
    }

    //data object class to represent a single
    class Auction{
        private String name;
        int auct_id;

        public String getName() {
            return name;
        }
        public int getAuctId() {
            return auct_id;
        }

        public Auction(String name, int auct_id){
            this.name = name;
            this.auct_id = auct_id;
        }

        @Override
        public String toString()
        {
            return name;
        }
    }

    class GetAuctionDetails extends AsyncTask<ArrayList<Auction>, String, JSONObject> {
        // Progress dialog
        private ProgressDialog pDialog;
        private JSONParser jParser = new JSONParser();

        // Note that if using emulator, use the address 10.0.2.2. If using a device then the only solution is wifi
        // On wifi network the address can change, so run ipconfig to verify (IPv4 address if not working)
        // Also ensure apache https.conf allows access (access from apache server sub-menu)
        //private static final String url_db_item = "http://192.168.1.110/android_connect/get_loans_data.php";

        String server_id = ((GlobalVars)getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars)getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();
        String client_id = ((GlobalVars)getApplicationContext()).get_client_id();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/active_auction_list.php";

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(ActiveAuctionList.this);
            pDialog.setMessage("Getting active auction list...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if details exists. If not, adds details and returns userID.
        // Else returns -1
        @Override
        protected JSONObject doInBackground(ArrayList<Auction>... data) {
            int success = 0;
            HashMap<String, String> qval = new HashMap<String, String>();
            qval.put("client_id",client_id);

            JSONObject json;
            JSONObject result = new JSONObject();

            try {

                if(protocol.equals("https")){
                    json = jParser.makeHttpsRequest(url_db_item,"POST", qval,
                            getApplicationContext(), server_id);
                }
                else {
                    json = jParser.makeHttpRequest(url_db_item,"POST", qval);
                }

                // Check success tag
                success = json.getInt("success");

                if(success == 1){
                    result = json;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            return result;
        }

        //After completing background task Dismiss the progress dialog
        @Override
        protected void onPostExecute(JSONObject json) {
            // dismiss the dialog once got all details
            try {
                int auct_rasize = json.getInt("auct_rasize");

                JSONArray jsonarraydata = json.getJSONArray("auct_data");
                String[] auction_data = new String[auct_rasize];

                // Add auction data
                for (int i = 0; i < auct_rasize; i++) {
                    JSONArray level = (JSONArray) jsonarraydata.get(i);
                    String auction_id = level.get(0).toString();
                    int auct_id=0;

                    try {
                        auct_id = Integer.parseInt(auction_id);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

                    String auction_date = level.get(1).toString();
                    String is_active = level.get(4).toString();
                    String is_concluded = level.get(5).toString();

                    String status;

                    if(is_concluded.equals("1")) {
                        status = "CONCLUDED";
                    }
                    else if(is_active.equals("1")) {
                        status = "ACTIVE";
                    }
                    else {
                        status = "PENDING";
                    }
                    auction_data[i] = "Auction " + auction_id + "\t\t\t\t" + auction_date + "\t\t\t\t" + status;
                    data.add(new Auction(auction_data[i], auct_id));
                }

                myListView.setAdapter(dbAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            Toast toast = Toast.makeText(getBaseContext(), "List of active auctions.", Toast.LENGTH_LONG);

            View toastView = toast.getView();
            toastView.setBackgroundResource(R.drawable.toast);
            toast.show();

            pDialog.dismiss();
        }
    }
}
