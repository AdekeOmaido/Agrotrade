package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class saleLogin extends AppCompatActivity {

    ImageView img;
    EditText pas,usr,email;

    Button button1, button2;


    @SuppressLint("WrongViewCast")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale_login);
        usr = (EditText) findViewById(R.id.username);
        pas = (EditText) findViewById(R.id.password);
        email = (EditText) findViewById(R.id.email);

//        img = (ImageView) findViewById(R.id.GoBackIcon);

        button1 = findViewById(R.id.loginButton);
        button2 = findViewById(R.id.joinButton);

    }

    public void joinBtn(View view) {
        Intent join = new Intent(saleLogin.this, Register.class);
        startActivity(join);
    }

    public void loginBtn(View view) {
        Intent login = new Intent(saleLogin.this, SalesList.class);
        startActivity(login);
    }

    public void submitBtn(View view) {
    }
}

