package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.dashboard.Details;
import java.util.ArrayList;


public class SalesList extends Activity {

    ListView myListView;
    Spinner mySpinner;
    ArrayAdapter<Auction>adapter;
    String[] categories = {"ALL","SALES"};



    //initialize listview and spinner,set their adapters

    private void initializeViews()
    {
        mySpinner = findViewById(R.id.mySpinner);
        mySpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categories));

        myListView = findViewById(R.id.myListView);
        myListView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getAuctions()));

        //spinner selection
        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long itemID) {
                if (position >= 0 && position < categories.length){
                    getSelectedCategoryData(position);
                }else{
                    Toast.makeText(SalesList.this, "selected category doesn't exist!", Toast.LENGTH_SHORT).show();
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
    //populate arraylist
    private ArrayList<Auction> getAuctions(){
        ArrayList<Auction> data = new ArrayList<>();
        data.clear();


        data.add(new Auction("Sale 1", "COMPLETE", 2));
        data.add(new Auction("Sale 2", "SORTING", 2));
        data.add(new Auction("Sale 3", "SCHEDULED", 2));
        data.add(new Auction("Sale 4", "TRANSPORT", 2));
        data.add(new Auction("Sale 5", "AUCTION", 2));

        return data;
    }

    //get i get the categories data and bind to view list
    private void getSelectedCategoryData(int categoryID)
    {
        //arraylist to hold selected auction

        ArrayList<Auction> auctions = new ArrayList<>();
        if(categoryID ==0 )
        {
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getAuctions());
        }else{
            //filter by ID
            for (Auction auction : getAuctions()){
                if(auction.getCategoryId() == categoryID){
                    auctions.add(auction);
                }
            }

            //instantiate adapter
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, auctions);
        }

        //set adapter to grid view
        myListView.setAdapter(adapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_list);

        myListView = findViewById(R.id.myListView);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long itemID) {

                Intent intent = new Intent(SalesList.this, sellItemDetails.class);
                startActivity(intent);
            }
        });

        initializeViews();

    }



    //data object class to represent a single

    class Auction{
        private String name;
        private String status;
        private int categoryID;

        public String getName() {
            return name;
        }

        public String getStatus() {
            return status;
        }

        public int getCategoryId() {
            return categoryID;
        }

        public Auction(String name, String status, int categoryID){
            this.name = name;
            this.status = status;
            this.categoryID = categoryID;
        }

        @Override
        public String toString()
        {
            return name;
        }
    }

}