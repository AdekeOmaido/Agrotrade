package com.example.dashboard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class SubmitBidActivity extends AppCompatActivity {
    Button submit_bid;
    EditText bid_amount;

    LoanDetails qv;
    LoanDetails queryValues;
    private static final String TAG_SUCCESS = "success";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_bid);

        bid_amount = (EditText) findViewById(R.id.bid_amount);
        submit_bid = findViewById(R.id.submitbidButton);
        queryValues = new LoanDetails();

        Intent intent = getIntent();
        qv = (LoanDetails)intent.getParcelableExtra("query_values");

        queryValues.push("client_id", qv.get("client_id"));
        queryValues.push("auction_id", qv.get("auction_id"));

        submit_bid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("debug","submitting bid");
                submit_bid(queryValues);
            }
        });
    }

    public void submit_bid(LoanDetails queryValues){
        String bid_amt = bid_amount.getText().toString().trim();

        queryValues.push("bid_amt",bid_amt);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //Check internet connection
        Context context = getApplicationContext();
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        if (activeNetwork != null) {
            Log.d("debug","Connected to internet");
            // connected to the internet
            // Add user details to remote DB. Method returns userid, returns -1 if username exists
            SubmitBidRemoteDB submitBidDB = new SubmitBidRemoteDB();
            submitBidDB.execute(queryValues);
        } else {
            // not connected to the internet
            Log.d("debug","Not connected to internet");
            Toast.makeText(getBaseContext(), "Internet connection unavailable.", Toast.LENGTH_LONG).show();
        }

    }

    class SubmitBidRemoteDB extends AsyncTask<LoanDetails, String, LoanDetails>
    {
        // Progress dialog
        private ProgressDialog pDialog;
        JSONParser jParser = new JSONParser();

        String server_id = ((GlobalVars) getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars) getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/submit_bid.php";
        String username;

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(SubmitBidActivity.this);
            pDialog.setMessage("Submitting bid to auction...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if user exists. If not, adds user details and returns userID.
        // Else returns -1
        protected LoanDetails doInBackground(LoanDetails... qval) {

            int success = 0;
            String message;

            try {

                JSONObject json;

                // Send LoanDetails object to JSON parser
                if (protocol.equals("https")) {
                    json = jParser.makeHttpsRequest(url_db_item, "POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                } else {
                    json = jParser.makeHttpRequest(url_db_item, "POST", qval[0].getValues());
                }

                // Check log for response
                Log.d("Submit response", json.toString());

                // Check success tag
                success = json.getInt(TAG_SUCCESS);
                message = json.getString("message");

                //Success value is always returned. Push to array before checking any other
                //values in case any exceptions are thrown for other 'null' values
                qval[0].push("success", Integer.toString(success));
                qval[0].push("message", message);

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }

            return qval[0];
        }

        protected void onPostExecute(LoanDetails qval) {

            int success = Integer.valueOf(qval.getValues().get("success"));

            if (success == -1) {
                Toast.makeText(getBaseContext(), "Server connection error.", Toast.LENGTH_LONG).show();
                pDialog.dismiss();

            } else {
                String message = qval.getValues().get("message");
                Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();
                pDialog.dismiss();

                Intent i = new Intent(SubmitBidActivity.this, BidsDetails.class);
                startActivity(i);
            }
        }
    }
}
