package com.example.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;


public class ActiveRequests extends Activity {

    ListView myListView;
    ArrayAdapter<Auction>adapter;



    //initialize listview and spinner,set their adapters

    private void initializeViews()
    {

        myListView = findViewById(R.id.myListView);
        myListView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getAuctions()));

    }
    //populate arraylist
    private ArrayList<Auction> getAuctions(){
        ArrayList<Auction> data = new ArrayList<>();
        data.clear();

        data.add(new Auction("REQUEST 1", "CLOSED"));
        data.add(new Auction("REQUEST 2", "LIVE"));
        data.add(new Auction("REQUEST 3", "PENDING"));
        data.add(new Auction("REQUEST 4", "CLOSED"));
        data.add(new Auction("REQUEST 5", "LIVE"));

        return data;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_requests);

        myListView = findViewById(R.id.myListView);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long itemID) {

                Intent intent = new Intent(ActiveRequests.this, Map.class);
                startActivity(intent);
            }
        });

        initializeViews();

    }

    //data object class to represent a single

    class Auction{
        private String name;
        private String status;
        //private int categoryID;

        public String getName() {
            return name;
        }

        public String getStatus() {
            return status;
        }

//        public int getCategoryId() {
//            return categoryID;
//        }

        public Auction(String name, String status){
            this.name = name;
            this.status = status;
//            this.categoryID = categoryID;
        }

        @Override
        public String toString()
        {
            return name;
        }

    }

}