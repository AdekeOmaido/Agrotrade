package com.example.dashboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class bidsListAdapter extends ArrayAdapter<auction> {

    private static final String TAG = "bidsListAdapter";

    private Context mContext;
    int mResource;

    public bidsListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<auction> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        String name = getItem(position).getName();
        String status = getItem(position).getStatus();

        bids bids = new bids(name,status);

        LayoutInflater inflater = LayoutInflater.from(mContext); {
            convertView = inflater.inflate(mResource, parent, false);

            TextView tvName = (TextView) convertView.findViewById(R.id.textView1);
            TextView tvStatus = (TextView) convertView.findViewById(R.id.textView2);

            tvName.setText(name);
            tvStatus.setText(status);

            return convertView;

        }
    }
}
