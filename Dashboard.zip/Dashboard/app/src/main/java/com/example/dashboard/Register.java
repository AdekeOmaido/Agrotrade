package com.example.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    Button _btnjoin;
    ImageView _backLogin;
    EditText _username;
    EditText _password;
    EditText _verify_password;
    EditText _email;
    LoanDetails queryValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        queryValues = new LoanDetails();

        _username = (EditText)findViewById(R.id.username);
        _password = (EditText)findViewById(R.id.password);
        _verify_password = (EditText)findViewById(R.id.verify_password);
        _email = (EditText)findViewById(R.id.email);
        _btnjoin = findViewById(R.id.joinUsButton);
        _backLogin = findViewById(R.id.backToLogin);

        _btnjoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(validate()) {
                    queryValues.push("username", _username.getText().toString().trim());
                    queryValues.push("password", _password.getText().toString().trim());
                    queryValues.push("email", _email.getText().toString().trim());

                    //Move to more user details activity
                    Intent intent = new Intent(Register.this, RegisterDetails.class);
                    intent.putExtra("queryValues", queryValues);
                    startActivity(intent);
                }
            }
        });

        _backLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(Register.this, LoginActivity.class);
                startActivity(back);
            }
        });
    }

    public boolean validate() {
        boolean valid = true;

        String username = _username.getText().toString().trim();
        String email = _email.getText().toString().trim();
        String password = _password.getText().toString().trim();
        String verify_password = _verify_password.getText().toString().trim();

        if (username.isEmpty() || username.length() < 4 ) {
            _username.setError("Enter a valid username");
            valid = false;
        } else {
            _username.setError(null);
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _email.setError("Enter a valid email address");
            valid = false;
        } else {
            _email.setError(null);
        }

        if (password.isEmpty() || password.length() < 7) {
            _password.setError("Password must be at least 7 characters");
            _password.setText("");
            _verify_password.setText("");
            valid = false;
        }
        else if (!password.matches(".*\\d+.*")) {
            _password.setError("Password must include at least one digit");
            valid = false;
        }
        else if (!password.equals(verify_password)){
            _verify_password.setError("Password verification must match password");
            valid = false;
        } else {
            _password.setError(null);
        }

        return valid;
    }

}
