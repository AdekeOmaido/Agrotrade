package com.example.dashboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;

public class DBHelper extends SQLiteOpenHelper {

    //declaring the schema first for the database
    public static final String DATABASE_NAME = "test_agrotradedb";
    public static final String TABLE_NAME = "auction";
    public static final String COL_1 = "auction_id";
    public static final String COL_2 = "produce_type";
    public static final String COL_3 = "status";

    SQLiteDatabase db;
    Cursor cursor;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table " + TABLE_NAME + " (auction_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                " winner_id INT, produce_type VARCHAR, winning_bid FLOAT, price_per_unit FLOAT,produce_quality enum" +
                ", auction_duration FLOAT, low_limit FLOAT,high_limit FLOAT,num_bids INT,status  TEXT)");

//
//        db.execSQL("INSERT INTO auction (auction_id, winner_id, produce_type, winning_bid, price_per_unit, produce_quality, auction_duration, low_limit, high_limit, num_bids, status) " +
//                "VALUES('1', '1000', 'Bananas','100', '10', 'A', '10.00', '50', '150', '10', 'Closed');");

        //populate dummy data
//        db.execSQL("INSERT INTO auction (auction_id, produce_type,status) " + "VALUES('1', 'Bananas', 'Live');");
//        db.execSQL("INSERT INTO auction (auction_id, produce_type,status) " + "VALUES('2', 'Pineapples', 'Closed');");
//        db.execSQL("INSERT INTO auction (auction_id, produce_type,status) " + "VALUES('3', 'Cabbages', 'Auction');");

    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);//Drop older table if exists
    }

    public long insertData(String auction_id, String produce_type, String status) {
        ContentValues contentValues = new ContentValues();//used to write data to the data base in the required order
        contentValues.put(COL_1, auction_id);
        contentValues.put(COL_2, produce_type);
        contentValues.put(COL_3, status);

        db = this.getWritableDatabase();
        long id = db.insert(DBHelper.TABLE_NAME, null, contentValues);
        return id;
    }
    //this method checks if te database exists or not
    public static boolean doesDatabaseExist(Context context) {
        File dbFile = context.getDatabasePath(DATABASE_NAME);
        return dbFile.exists();
    }
    //method to fetch user profile from DB
    public ContentValues getUserProfile(){
        //initialize a readable db object
        db = this.getReadableDatabase();
        //create an object for holding return data
        ContentValues userProfile = new ContentValues();
        //set success to 0
        // 0: client profile not found or more than 1 users exist in db
        // 1:  only 1 user exists
        userProfile.put("success", 0);

        //create query string
        String query = " SELECT * FROM " + TABLE_NAME + " WHERE " +
                COL_1 + " = 1";
        //execute query and pass result to cursor
        cursor = db.rawQuery(query, null);

        //check if cursor contains any values
        if (cursor != null){
            cursor.moveToFirst();
            if (cursor.getCount() == 1) {
                userProfile.put("auction_id", cursor.getInt(1));
                userProfile.put("produce_type", cursor.getString(2));
                userProfile.put("status", cursor.getString(3));
                userProfile.put("success", 1);
            }
        }
        return userProfile;
    }
}
