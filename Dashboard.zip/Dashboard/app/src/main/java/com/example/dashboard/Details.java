package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class Details extends AppCompatActivity {

    Button submit, back;
    TextView item, quantity, quality;
    int auct_selected;
    LoanDetails queryValues;
    LoanDetails qv;
    String auction_id;
    String time_end;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        submit = findViewById(R.id.submitButton);
        submit.setEnabled(true);

        back = findViewById(R.id.backButton);

        item = findViewById(R.id.txtitem);
        quantity = findViewById(R.id.txtqty);
        quality = findViewById(R.id.txtquality);
        queryValues = new LoanDetails();

        //Get auction ID and load auction details
        Intent intent = getIntent();
        qv = (LoanDetails)intent.getParcelableExtra("query_values");
        auction_id = qv.get("auction_id");
        time_end = qv.get("time_end");

        Log.d("Auction close: ",time_end);

        String client_id = ((GlobalVars) getApplicationContext()).get_client_id();
        queryValues.push("auction_id", auction_id);
        queryValues.push("client_id", client_id);

        RetrieveAuction ret = new RetrieveAuction();
        ret.execute(queryValues);

    }

    public void submitBtn(View view) {
        Intent i = new Intent(Details.this, TermsConditions.class);
        i.putExtra("query_values", queryValues);
        startActivity(i);
    }

    public void backBtn(View view) {
        Intent back = new Intent(Details.this, Auctiondetails.class);
        startActivity(back);
    }

    class RetrieveAuction extends AsyncTask<LoanDetails, String, LoanDetails> {

        // Progress dialog
        private ProgressDialog pDialog;
        JSONParser jParser = new JSONParser();

        String server_id = ((GlobalVars) getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars) getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/retrieve_auction.php";
        String message;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(Details.this);
            pDialog.setMessage("Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if user exists. If not, adds user details and returns userID.
        // Else returns -1
        protected LoanDetails doInBackground(LoanDetails... qval) {

            int success = 0;
            LoanDetails auct_details = new LoanDetails();

            try {

                JSONObject json;

                // Send LoanDetails object to JSON parser
                if (protocol.equals("https")) {
                    json = jParser.makeHttpsRequest(url_db_item, "POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                } else {
                    json = jParser.makeHttpRequest(url_db_item, "POST", qval[0].getValues());
                }

                //Success value is always returned. Push to array before checking any other
                //values in case any exceptions are thrown for other 'null' values
                success = Integer.parseInt(json.getString("success"));

                //Check other values if success is not -1 (i.e. no exception thrown)
                if(success != -1) {
                    message = json.getString("message");

                    auct_details.push("success", Integer.toString(success));
                    auct_details.push("message", message);
                    auct_details.push("produce_type", json.getString("produce_type"));
                    auct_details.push("produce_qty", json.getString("produce_qty"));
                    auct_details.push("produce_quality", json.getString("produce_quality"));
                    auct_details.push("bid_submitted", json.getString("bid_submitted"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }

            return auct_details;
        }

        protected void onPostExecute(LoanDetails qval) {

            int success = Integer.valueOf(qval.getValues().get("success"));

            if (success == -1) {
                Toast.makeText(getBaseContext(), "Server connection error.", Toast.LENGTH_LONG).show();
                pDialog.dismiss();

            } else {
                String message = qval.getValues().get("message");
                if (success == 1) {
                    pDialog.dismiss();

                    item.setText(qval.get("produce_type"));
                    quantity.setText(qval.get("produce_qty"));
                    quality.setText(qval.get("produce_quality"));

                    int bid_submitted = Integer.parseInt(qval.get("bid_submitted"));

                    if(bid_submitted == 1){
                        submit.setEnabled(false);
                        submit.setBackgroundColor(Color.GRAY);
                    }
                } else {
                    Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();
                    pDialog.dismiss();
                }
            }
        }
    }

}