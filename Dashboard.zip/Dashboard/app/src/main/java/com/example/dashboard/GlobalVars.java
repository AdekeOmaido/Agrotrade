package com.example.dashboard;


import android.app.Application;

public class GlobalVars extends Application {

        //Protocol either http or https
        private static final String protocol = "http";
        private static final String server_id = "52.207.177.250";

        private static final String cur_folder = "tradesandbox";
        private static String client_id;
        //private String selected_auction;

        //App version
        private static final String app_version = "1.0";

        public String get_server_id(){
            return server_id;
        }

        public String get_protocol() {return protocol; }

        public String get_cur_folder() {return cur_folder; }

        public String get_app_version(){return app_version;}

        public void set_client_id(String cl_id){
                client_id = cl_id;
        }

        public String get_client_id(){
                return client_id;
        }

        //public void set_selected_auction(String a_id){selected_auction = a_id;}

        //public String get_selected_auction(){return selected_auction;}

    }
