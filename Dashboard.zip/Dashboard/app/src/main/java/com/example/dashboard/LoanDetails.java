package com.example.dashboard;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class LoanDetails implements Parcelable {

    private HashMap<String, String> values;

    public LoanDetails (){
        values = new HashMap<String, String>();
    }

    private LoanDetails(Parcel source){
        values = new HashMap<String,String>();

        final int N = source.readInt();

        for(int i=0; i<N; i++){
            String key = source.readString();
            String value = source.readString();
            values.put(key,value);
        }
    }

    public void push(String key, String val){
        values.put(key, val);
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags){
        final int N = values.size();
        out.writeInt(N);

        if (N > 0) {
            for (Map.Entry<String, String> entry : values.entrySet()) {
                out.writeString(entry.getKey());
                out.writeString(entry.getValue());
            }
        }
    }

    public static final Creator<LoanDetails> CREATOR = new Creator<LoanDetails>() {

        @Override
        public LoanDetails createFromParcel(Parcel source) {
            return new LoanDetails(source);
        }

        @Override
        public LoanDetails[] newArray(int size) {
            return new LoanDetails[size];
        }
    };


    // Create String in URL post format from hashmap
    public String toPostString()throws UnsupportedEncodingException {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        for(Map.Entry<String,String> entry : values.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }

    public HashMap<String, String> getValues(){
        return values;
    }

    public String get(String key){return values.get(key);}

}
