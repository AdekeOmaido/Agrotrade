package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
//import android.text.style.TypefaceSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.view.View;
import android.widget.Button;

public class Auctioncategory extends AppCompatActivity  {

    Button sale, buy, logistics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auctioncategory);

        sale = findViewById(R.id.saleButton);
        buy = findViewById(R.id.buyButton);
        logistics = findViewById(R.id.logisticsButton);

        String text = "SELL MY PRODUCE\n I WANT TO SELL PRODUCE TO CUSTOMERS";
        String text1 = "PURCHASE PRODUCE\n I WANT TO PURCHASE FOR PERSONAL USE";
        String text2 = "LOGISTICS\n I DEAL WITH TRANSPORTATION";

        SpannableString ss= new SpannableString(text);
        SpannableString ss1= new SpannableString(text1);
        SpannableString ss2= new SpannableString(text2);

        StyleSpan italicSpan = new StyleSpan(Typeface.ITALIC);
        ForegroundColorSpan fcsGray = new ForegroundColorSpan(Color.LTGRAY);

        ss.setSpan(italicSpan,17,52, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE );
        ss.setSpan(fcsGray,17,52,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(new RelativeSizeSpan(0.7f), 17, 52, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        ss1.setSpan(italicSpan,18,53, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE );
        ss1.setSpan(fcsGray,18,53,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss1.setSpan(new RelativeSizeSpan(0.7f), 18, 53, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        ss2.setSpan(italicSpan,11,37, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE );
        ss2.setSpan(fcsGray,11,37,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss2.setSpan(new RelativeSizeSpan(0.7f), 11, 37, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        sale.setText(ss);
        buy.setText(ss1);
        logistics.setText(ss2);

    }

    public void saleBtn(View view){
        Intent sale = new Intent(Auctioncategory.this, Bundlesdetails.class);
        startActivity(sale);
    }

    public void buyBtn(View view) {
        Intent buy = new Intent(Auctioncategory.this, Auctiondetails.class);
        startActivity(buy);
    }

    public void logisticsBtn(View view) {
        Intent logistics = new Intent(Auctioncategory.this, ActiveRequests.class);
        startActivity(logistics);
    }
}



