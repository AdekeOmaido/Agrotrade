package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Auctioncategory extends AppCompatActivity {

    Button sale, buy, logistics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auctioncategory);

        sale = findViewById(R.id.saleButton);
        buy = findViewById(R.id.buyButton);
        logistics = findViewById(R.id.logisticsButton);

    }

    public void saleBtn(View view){
        Intent sale = new Intent(Auctioncategory.this, saleLogin.class);
        startActivity(sale);
    }

    public void buyBtn(View view) {
        Intent buy = new Intent(Auctioncategory.this, Auctiondetails.class);
        startActivity(buy);
    }

    public void logisticsBtn(View view) {
        Intent logistics = new Intent(Auctioncategory.this, ActiveRequests.class);
        startActivity(logistics);
    }
}