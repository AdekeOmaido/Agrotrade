package com.example.dashboard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.logging.Level;

public class AuctionDisplay extends AppCompatActivity {

        TextView[][] textViews = new TextView[5][3];

        //TextView tv11;
        //TextView tv12;
        //TextView tv13;

    HashMap<String,String> user_details = new HashMap<String, String>();

    SharedPreferences sharedPref;
    LoanDetails queryValues = new LoanDetails();

    public static final String PREF = "pref";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auction_display);

        sharedPref = getSharedPreferences(PREF, Context.MODE_PRIVATE);

        textViews[0][0]= (TextView)findViewById(R.id.tv11);
        textViews[0][1]= (TextView)findViewById(R.id.tv12);
        textViews[0][2]= (TextView)findViewById(R.id.tv13);
        textViews[1][0]= (TextView)findViewById(R.id.tv21);
        textViews[1][1]= (TextView)findViewById(R.id.tv22);
        textViews[1][2]= (TextView)findViewById(R.id.tv23);
        textViews[2][0]= (TextView)findViewById(R.id.tv31);
        textViews[2][1]= (TextView)findViewById(R.id.tv32);
        textViews[2][2]= (TextView)findViewById(R.id.tv33);
        textViews[3][0]= (TextView)findViewById(R.id.tv41);
        textViews[3][1]= (TextView)findViewById(R.id.tv42);
        textViews[3][2]= (TextView)findViewById(R.id.tv43);
        textViews[4][0]= (TextView)findViewById(R.id.tv51);
        textViews[4][1]= (TextView)findViewById(R.id.tv52);
        textViews[4][2]= (TextView)findViewById(R.id.tv53);

        //tv11 = (TextView)findViewById(R.id.tv11);
        //tv12 = (TextView)findViewById(R.id.tv12);
        //tv13 = (TextView)findViewById(R.id.tv13);
        textViews[0][2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( AuctionDisplay.this,Auctiondetails.class);
                startActivity(intent);

                Toast.makeText(AuctionDisplay.this,"Tab Changed", Toast.LENGTH_SHORT).show();
            }
        });



        try{

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            //Check internet connection
            Context context = getApplicationContext();
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            if (activeNetwork != null) {
                //connected to the internet
                GetAuctionDetails getAuctionDetails = new GetAuctionDetails();
                queryValues.push("process_id","Get auction details");
                getAuctionDetails.execute(queryValues);
            } else {
                // not connected to the internet
                Toast.makeText(getBaseContext(), "Internet connection unavailable.", Toast.LENGTH_LONG).show();
            }

        }catch(NullPointerException e){
            e.printStackTrace();
        }

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), Auctioncategory.class);
        startActivity(intent);
    }

    class GetAuctionDetails extends AsyncTask<LoanDetails, String, JSONObject> {
        // Progress dialog
        private ProgressDialog pDialog;
        private JSONParser jParser = new JSONParser();

// Note that if using emulator, use the address 10.0.2.2. If using a device then the only solution is wifi
        // On wifi network the address can change, so run ipconfig to verify (IPv4 address if not working)
        // Also ensure apache httpd.conf allows access (access from apache server sub-menu)
        //private static final String url_db_item = "http://192.168.1.110/android_connect/get_loans_data.php";

        String server_id = ((GlobalVars)getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars)getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/get_auction_details.php";

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(AuctionDisplay.this);
            pDialog.setMessage("Getting auction details...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if details exists. If not, adds details and returns userID.
        // Else returns -1
        @Override
        protected JSONObject doInBackground(LoanDetails... qval) {
            int success = 0;

            String[] produce_type;
            String[] status;

            JSONObject json;
            JSONObject result = new JSONObject();

            try {

                if(protocol.equals("https")){
                    json = jParser.makeHttpsRequest(url_db_item,"POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                }
                else {
                    json = jParser.makeHttpRequest(url_db_item,"POST", qval[0].getValues());
                }

                // Check success tag
                success = json.getInt("success");

                if(success == 1){
                    result = json;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            return result;

        }

        //After completing background task Dismiss the progress dialog
        @Override
        protected void onPostExecute(JSONObject json) {
            // dismiss the dialog once got all details
            try {
                int ra_size = json.getInt("rasize");

                //Ensure we do not process more than 5 items until
                //we have code for a dynamic list
                if(ra_size > 5){
                    ra_size = 5;
                }
                JSONArray jsonarraydata = json.getJSONArray("data");
                String[] produce_type = new String[ra_size];
                String[] status = new String[ra_size];

                for (int i = 0; i < ra_size; i++) {
                    JSONArray level = (JSONArray) jsonarraydata.get(i);
                    produce_type[i] = level.get(1).toString();
                    status[i] = level.get(2).toString();
                    textViews[i][1].setText(produce_type[i]);
                    textViews[i][2].setText(status[i]);
                }

                //tv12.setText(produce_type[0]);
                //tv13.setText(status[0]);
                //Log.d("Produce data", produce_type[0]);
                //Log.d("Produce data", produce_type[1]);
            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            Toast.makeText(getBaseContext(), "Live database auction details.", Toast.LENGTH_LONG).show();
            pDialog.dismiss();
        }
    }
}