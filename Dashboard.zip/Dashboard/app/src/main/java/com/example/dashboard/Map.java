package com.example.dashboard;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.view.View;
import android.widget.Button;

public class Map extends FragmentActivity implements OnMapReadyCallback{

    GoogleMap mapAPI;
    SupportMapFragment mapFragment;
    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapAPI);

        mapFragment.getMapAsync(this);

        button1 = findViewById(R.id.calculate);
    }

    public void acceptBtn(View view) {
        Intent calc = new Intent(Map.this, SalesList.class);
        startActivity(calc);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mapAPI = googleMap;

        LatLng Shell = new LatLng(-1.2916404,36.8433947);

        mapAPI.addMarker(new MarkerOptions().position(Shell).title("Shell Petrol Station"));

        mapAPI.moveCamera(CameraUpdateFactory.newLatLng(Shell));
    }

}