package com.example.dashboard;

public class GetAuctionDetails {
    public void execute(LoanDetails queryValues) {
    }
}
