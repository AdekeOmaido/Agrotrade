package com.example.dashboard;

import android.app.ProgressDialog;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.StrictMode;
import android.util.Log;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.dashboard.LoanDetails;
import com.example.dashboard.JSONParser;
import com.example.dashboard.GlobalVars;
import org.json.JSONException;
import org.json.JSONObject;
//import android.widget.ImageView;

public class LoginActivity extends AppCompatActivity {

    public static final String TAG = "LoginActivity";

    //ImageView img;
    EditText pas,usr,email;

    Button button1, button2;

    LoanDetails queryValues = new LoanDetails();
    private static final String TAG_SUCCESS = "success";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usr = (EditText) findViewById(R.id.username);
        pas = (EditText) findViewById(R.id.password);
        email = (EditText) findViewById(R.id.email);

//        img = (ImageView) findViewById(R.id.GoBackIcon);

        button1 = findViewById(R.id.loginButton);
        button2 = findViewById(R.id.joinButton);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 login();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, Register.class);
                startActivity(i);
            }
        });

    }


    public void login(){
        String username = usr.getText().toString().trim();
        String password = pas.getText().toString().trim();

        queryValues.push("username",username);
        queryValues.push("password",password);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //Check internet connection
        Context context = getApplicationContext();
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        if (activeNetwork != null) {
            Log.d("debug","Connected to internet");
            // connected to the internet
            // Add user details to remote DB. Method returns userid, returns -1 if username exists
            VerifyUserRemoteDB verifyUser = new VerifyUserRemoteDB();
            verifyUser.execute(queryValues);
        } else {
            // not connected to the internet
            Log.d("debug","Not connected to internet");
            Toast.makeText(getBaseContext(), "Internet connection unavailable.", Toast.LENGTH_LONG).show();
            button1.setEnabled(true);
        }

    }


    class VerifyUserRemoteDB extends AsyncTask<LoanDetails, String, LoanDetails>
    {
        // Progress dialog
        private ProgressDialog pDialog;
        JSONParser jParser = new JSONParser();

        String server_id = ((GlobalVars) getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars) getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/verify_user.php";
        String username;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(LoginActivity.this);
            pDialog.setMessage("Authenticating...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if user exists. If not, adds user details and returns userID.
        // Else returns -1
        protected LoanDetails doInBackground(LoanDetails... qval) {

            int success = 0;
            int client_id = -1;
            String message;

            try {

                JSONObject json;

                // Send LoanDetails object to JSON parser
                if (protocol.equals("https")) {
                    json = jParser.makeHttpsRequest(url_db_item, "POST", qval[0].getValues(),
                            getApplicationContext(), server_id);
                } else {
                    json = jParser.makeHttpRequest(url_db_item, "POST", qval[0].getValues());
                }

                // Check log for response
                Log.d("Submit response", json.toString());

                // Check success tag
                success = json.getInt(TAG_SUCCESS);

                //Success value is always returned. Push to array before checking any other
                //values in case any exceptions are thrown for other 'null' values
                qval[0].push("success", Integer.toString(success));

                //Check other values if success is not -1 (i.e. no exception thrown)
                if(success != -1) {

                    client_id = json.getInt("client_id");
                    message = json.getString("message");

                    qval[0].push("client_id", Integer.toString(client_id));
                    qval[0].push("message", message);

                    // Update current user
                    if (success == 1) {
                        username = qval[0].getValues().get("username");
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }

            return qval[0];
        }

        protected void onPostExecute(LoanDetails qval) {

            int success = Integer.valueOf(qval.getValues().get("success"));

            if (success == -1) {
                Toast.makeText(getBaseContext(), "Server connection error.", Toast.LENGTH_LONG).show();
                button1.setEnabled(true);
                pDialog.dismiss();

            } else {
                String message = qval.getValues().get("message");
                ((GlobalVars) getApplicationContext()).set_client_id(qval.getValues().get("client_id"));

                if (success == 1) {
                    button1.setEnabled(true);
                    Toast.makeText(getBaseContext(), "Connection Successful.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Auctioncategory.class);
                    startActivity(intent);
                    pDialog.dismiss();
                } else {
                    Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();
                    button1.setEnabled(true);
                    pDialog.dismiss();
                }
            }
        }
    }

    public boolean validate() {
        boolean valid = true;

        String username = usr.getText().toString().trim();
        String password = pas.getText().toString().trim();

        //For login, check only that username and password fields are not empty
        if (username.isEmpty()) {
            usr.setError("Enter a username");
            valid = false;
        } else {
            usr.setError(null);
        }

        //Password length must be at least 7, and contain a number
        if (password.isEmpty()) {
            pas.setError("Enter a password");
            valid = false;
        } else {
            pas.setError(null);
        }

        return valid;
    }
}
