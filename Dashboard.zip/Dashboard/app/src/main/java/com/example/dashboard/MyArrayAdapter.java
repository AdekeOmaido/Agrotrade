package com.example.dashboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyArrayAdapter extends RecyclerView.Adapter<MyViewHolder> {

    Context c;
    String[] auctions;

    public MyArrayAdapter(Context c, String[] auctions) {
        this.c = c;
        this.auctions = auctions;
    }

    @NonNull
    @Override
    //i am initializing my view holder and then inflating my layout
    //calling the inflate method and pass in the context
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(c).inflate(R.layout.model, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        //bind data
        holder.name.setText(auctions[position]);

    }

    @Override
    public int getItemCount() {
        return auctions.length;
    }
}
