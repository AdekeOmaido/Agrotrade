package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.dashboard.Details;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class BidsDetails extends AppCompatActivity {

    ListView myListView;
    Spinner mySpinner;
    ArrayAdapter<Auction>adapter;
    ArrayAdapter<Auction>dbAdapter;
    ArrayList<Auction> data;
    //String[] categories = {"ALL","AUCTION","MY BIDS"};
    String[] categories = {"MY BIDS","AUCTIONS"};
    LoanDetails queryValues;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bids_details);

        data = new ArrayList<>();
        queryValues = new LoanDetails();

        dbAdapter = new ArrayAdapter<Auction>(this, android.R.layout.simple_list_item_1, data);

        myListView = findViewById(R.id.myBidsListView);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long itemID) {
            }
        });

        myListView.setAdapter(dbAdapter);

        mySpinner = findViewById(R.id.myBidsSpinner);
        mySpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, categories));

        //spinner selection
        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long itemID) {
                String selection = (String) adapterView.getItemAtPosition(position);
                Log.d("Position of spinner: ", selection);

                if (selection.equals("AUCTIONS")){
                    Intent intent = new Intent(BidsDetails.this, Auctiondetails.class);
                    startActivity(intent);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        getBids(data);
    }

    //populate arraylist
    public void getBids(ArrayList<Auction> data){
        //data.clear();
        try{

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            //Check internet connection
            Context context = getApplicationContext();
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            if (activeNetwork != null) {
                //connected to the internet
                GetBidDetails getBidDetails = new GetBidDetails();
                getBidDetails.execute(data);
            } else {
                // not connected to the internet
                Toast.makeText(getBaseContext(), "Internet connection unavailable.", Toast.LENGTH_LONG).show();
            }

        }catch(NullPointerException e){
            e.printStackTrace();
        }
    }

    //data object class to represent a single
    class Auction{
        private String name;
        int auct_id;
        private String time_start;
        private String time_end;
        private int categoryID;

        public String getName() {
            return name;
        }

        public int getAuctId() {return auct_id;}

        public String getTimeStart() {return time_start;}

        public String getTimeEnd() {return time_end;}

        public int getCategoryId() {
            return categoryID;
        }

        public Auction(String name, int auct_id, String time_start, String time_end, int categoryID){
            this.name = name;
            this.auct_id = auct_id;
            this.time_start = time_start;
            this.time_end = time_end;
            this.categoryID = categoryID;
        }

        @Override
        public String toString()
        {
            return name;
        }
    }

    class GetBidDetails extends AsyncTask<ArrayList<Auction>, String, JSONObject> {
        // Progress dialog
        private ProgressDialog pDialog;
        private JSONParser jParser = new JSONParser();

        // Note that if using emulator, use the address 10.0.2.2. If using a device then the only solution is wifi
        // On wifi network the address can change, so run ipconfig to verify (IPv4 address if not working)
        // Also ensure apache httpd.conf allows access (access from apache server sub-menu)
        //private static final String url_db_item = "http://192.168.1.110/android_connect/get_loans_data.php";

        String server_id = ((GlobalVars)getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars)getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();
        String client_id = ((GlobalVars)getApplicationContext()).get_client_id();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/get_bid_details.php";

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(BidsDetails.this);
            pDialog.setMessage("Getting bid history...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        // PHP call checks if details exists. If not, adds details and returns userID.
        // Else returns -1
        @Override
        protected JSONObject doInBackground(ArrayList<Auction>... data) {
            int success = 0;
            HashMap<String, String> qval = new HashMap<String, String>();
            qval.put("client_id",client_id);

            JSONObject json;
            JSONObject result = new JSONObject();

            try {

                if(protocol.equals("https")){
                    json = jParser.makeHttpsRequest(url_db_item,"POST", qval,
                            getApplicationContext(), server_id);
                }
                else {
                    json = jParser.makeHttpRequest(url_db_item,"POST", qval);
                }

                // Check success tag
                success = json.getInt("success");
                Log.d("Success: ", Integer.toString(success));

                if(success == 1){
                    result = json;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            return result;
        }

        //After completing background task Dismiss the progress dialog
        @Override
        protected void onPostExecute(JSONObject json) {
            // dismiss the dialog once got all details
            try {
                // Add bid data
                int bid_rasize = json.getInt("bid_rasize");

                JSONArray jsonbiddata = json.getJSONArray("bid_data");
                String[] bid_data = new String[bid_rasize];

                for (int i = 0; i < bid_rasize; i++) {
                    JSONArray level = (JSONArray) jsonbiddata.get(i);
                    String auction_id = level.get(0).toString();
                    int auct_id=0;

                    try {
                        auct_id = Integer.parseInt(auction_id);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    String bid_date = level.get(1).toString();
                    String bid_amount = level.get(2).toString();
                    String time_start = "";
                    String time_end = "";

                    bid_data[i] = "Auction " + auction_id + "\n bid date: " + bid_date + "\n bid amount: " + bid_amount + "\n";
                    data.add(new Auction(bid_data[i], auct_id, time_start, time_end,2));
                }

                //Log.d("auction 1",data.get(0).getStatus());
                myListView.setAdapter(dbAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            Toast.makeText(getBaseContext(), "Live database bid details.", Toast.LENGTH_LONG).show();
            pDialog.dismiss();
        }
    }
}