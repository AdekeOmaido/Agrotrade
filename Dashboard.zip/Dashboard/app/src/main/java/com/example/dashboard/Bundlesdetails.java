package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Bundlesdetails extends AppCompatActivity {

    ListView myListView;
    ArrayAdapter<Auction>adapter;
    ArrayAdapter<Auction>dbAdapter;
    ArrayList<Auction> data;

    Button newbundle;

    LoanDetails queryValues;
    int bundle_selected;
//    String date_time_open;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bundlesdetails);

        newbundle = findViewById(R.id.newbundle);

        data = new ArrayList<>();
        queryValues = new LoanDetails();
        dbAdapter = new ArrayAdapter<Auction>(this, android.R.layout.simple_list_item_1, data);

        myListView = findViewById(R.id.myListView);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long itemID) {

                Auction dt = (Auction)adapterView.getItemAtPosition(position);
                bundle_selected = dt.getBundleId();
//                date_time_open = dt.getTimeOpen();

                Log.d("Selected bundle: ",Integer.toString(bundle_selected));

                queryValues.push("bundle_id", Integer.toString(bundle_selected));
//                queryValues.push("date_time_open", date_time_open);

                Intent intent = new Intent(Bundlesdetails.this, bundledescription.class);
                intent.putExtra("query_values", queryValues);
                startActivity(intent);
            }
        });

        myListView.setAdapter(dbAdapter);

        getAuctions(data);
    }

    public void addBtn(View view){
        Intent sale = new Intent(Bundlesdetails.this, bundles.class);
        startActivity(sale);
    }

    //populate arraylist
    public void getAuctions(ArrayList<Auction> data){
        //data.clear();
        try{

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            //Check internet connection
            Context context = getApplicationContext();
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            if (activeNetwork != null) {
                //connected to the internet
                GetBundleDetails getBundleDetails = new GetBundleDetails();
                getBundleDetails.execute(data);
            } else {
                // not connected to the internet
                Toast toast = Toast.makeText(getBaseContext(), "Internet connection unavailable.", Toast.LENGTH_LONG);

                View toastView = toast.getView();
                toastView.setBackgroundResource(R.drawable.toast);
                toast.show();
            }

        }catch(NullPointerException e){
            e.printStackTrace();
        }
    }

    //data object class to represent a single
    class Auction{
        private String name;
        int bund_id;
//        private String date_time_open;

        public String getName() {
            return name;
        }

        public int getBundleId() {return bund_id;}

//        public String getTimeOpen() {return date_time_open;}

        public Auction(String name, int bund_id){
            this.name = name;
            this.bund_id = bund_id;
//            this.date_time_open = date_time_open;
        }

        @Override
        public String toString()
        {
            return name;
        }
    }

    class GetBundleDetails extends AsyncTask<ArrayList<Auction>, String, JSONObject> {
        // Progress dialog
        private ProgressDialog pDialog;
        private JSONParser jParser = new JSONParser();

        // Note that if using emulator, use the address 10.0.2.2. If using a device then the only solution is wifi
        // On wifi network the address can change, so run ipconfig to verify (IPv4 address if not working)
        // Also ensure apache httpd.conf allows access (access from apache server sub-menu)
        //private static final String url_db_item = "http://192.168.1.110/android_connect/get_loans_data.php";

        String server_id = ((GlobalVars)getApplicationContext()).get_server_id();
        String protocol = ((GlobalVars)getApplicationContext()).get_protocol();
        String cur_folder = ((GlobalVars)getApplicationContext()).get_cur_folder();
        String client_id = ((GlobalVars)getApplicationContext()).get_client_id();

        private String url_db_item = protocol+"://"+ server_id + "/"+cur_folder+"/get_bundle_details.php";

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(Bundlesdetails.this);
            pDialog.setMessage("Getting bundle details...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }
        // PHP call checks if details exists. If not, adds details and returns userID.
        // Else returns -1
        @Override
        protected JSONObject doInBackground(ArrayList<Auction>... data) {
            int success = 0;
            HashMap<String, String> qval = new HashMap<String, String>();
            qval.put("client_id",client_id);

            JSONObject json;
            JSONObject result = new JSONObject();

            try {

                if(protocol.equals("https")){
                    json = jParser.makeHttpsRequest(url_db_item,"POST", qval,
                            getApplicationContext(), server_id);
                }
                else {
                    json = jParser.makeHttpRequest(url_db_item,"POST", qval);
                }

                // Check success tag
                success = json.getInt("success");

                if(success == 1){
                    result = json;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            return result;
        }

        //After completing background task Dismiss the progress dialog
        @Override
        protected void onPostExecute(JSONObject json) {
            // dismiss the dialog once got all details
            try {
                int auct_rasize = json.getInt("auct_rasize");

                JSONArray jsonarraydata = json.getJSONArray("auct_data");
                String[] bundle_data = new String[auct_rasize];

                // Add auction data
                for (int i = 0; i < auct_rasize; i++) {
                    JSONArray level = (JSONArray) jsonarraydata.get(i);
                    String bundle_id = level.get(0).toString();
                    int bund_id=0;

                    try {
                        bund_id = Integer.parseInt(bundle_id);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

//                    String date_time_open = level.get(1).toString();
                    String status = level.get(2).toString();

                    bundle_data[i] = "Sale " + bundle_id + "\t\t\t\t" + status;
                    data.add(new Auction(bundle_data[i], bund_id));
                }

                myListView.setAdapter(dbAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
            Toast toast = Toast.makeText(getBaseContext(), "Live database bundle details.", Toast.LENGTH_LONG);

            View toastView = toast.getView();
            toastView.setBackgroundResource(R.drawable.toast);
            toast.show();

            pDialog.dismiss();
        }
    }
}