package com.example.dashboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class DisplayAdapter extends BaseAdapter {
    private Context mContext;
    //list fields to be displayed
    private ArrayList<String> auction_id;
    private ArrayList<String> produce_type;
    private ArrayList<String> status;


    public DisplayAdapter(Context c, ArrayList<String> auction_id, ArrayList<String> produce_type, ArrayList<String> status) {
        this.mContext = c;
        //transfer content from database to temporary memory
        this.auction_id = auction_id;
        this.produce_type = produce_type;
        this.status = status;
    }

    public int getCount() {
        // TODO Auto-generated method stub
        return auction_id.size();
    }

    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    public View getView(int pos, View child, ViewGroup parent) {
        Holder mHolder;
        LayoutInflater layoutInflater;
        if (child == null) {
            layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.listcell, null);
            mHolder = new Holder();

            //link to TextView
            mHolder.txtstafid = (TextView) child.findViewById(R.id.txtstafid);
            mHolder.txtnama = (TextView) child.findViewById(R.id.txtnama);
            mHolder.txtjbt = (TextView) child.findViewById(R.id.txtjbt);
            child.setTag(mHolder);
        } else {
            mHolder = (Holder) child.getTag();
        }
        //transfer to TextView in screen
        mHolder.txtstafid.setText(auction_id.get(pos));
        mHolder.txtnama.setText(produce_type.get(pos));
        mHolder.txtjbt.setText(status.get(pos));


        return child;
    }

    public class Holder {
        TextView txtstafid;
        TextView txtnama;
        TextView txtjbt;
    }

}
