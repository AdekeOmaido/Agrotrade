package com.example.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class TermsConditions extends AppCompatActivity {

    Button accept, decline;
    TextView txtTerms;
    String terms_text;
    LoanDetails queryValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.terms_conditions);

        accept = findViewById(R.id.acceptButton);
        decline = findViewById(R.id.declineButton);
        txtTerms = findViewById(R.id.terms_text);

        //Get auction info
        Intent intent = getIntent();
        queryValues = (LoanDetails)intent.getParcelableExtra("query_values");

        terms_text = "1. Definitions.\n\n";
        terms_text += "a) Auction refers to the sale of goods by first-price sealed bid.\n";
        terms_text += "b) Bid refers to the purchase price submitted for an auction lot.\n";
        terms_text += "c) Auction winner refers to the individual or entity that submits ";
        terms_text += "the highest price in a sealed bid auction.\n";
        terms_text += "d) First-price sealed bid auction refers to an auction where the highest bid ";
        terms_text += "wins and is the price paid for the auction lot.\n";
        terms_text += "2. Payment.\n\n";
        terms_text += "Submission of an auction bid represents a legally binding agreement ";
        terms_text += "with the obligation to make a payment.\n\n";
        terms_text += "3. Event of Default.\n\n";

        txtTerms.setText(terms_text);
    }

    public void acceptBtn(View view) {
        Intent int_accept = new Intent(TermsConditions.this, SubmitBidActivity.class);
        //pass auction info
        int_accept.putExtra("query_values", queryValues);
        startActivity(int_accept);
    }

    public void declineBtn(View view) {
        Intent back = new Intent(TermsConditions.this, Auctiondetails.class);
        startActivity(back);
    }
}
