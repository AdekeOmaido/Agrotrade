package com.example.dashboard;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

        private Spinner spnWindow;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spnWindow = findViewById(R.id.spnWindow);

        List<String> window = new ArrayList<>();
        window.add("AUCTIONS");
        window.add("MY BID");

        ArrayAdapter<String> windowAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, window);
        windowAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnWindow.setAdapter(windowAdapter);

        spnWindow.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String yourWindow = spnWindow.getSelectedItem().toString();
                if(!yourWindow.equals("AUCTIONS")){
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}