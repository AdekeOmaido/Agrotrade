package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;

public class ArrayList extends AppCompatActivity {

    RecyclerView recycler;

    String[] auctions ={"Auction One","Auction Two","Auction Three","Action Four","Auction Five","Auction Six","Auction Seven"
            ,"Auction Eight"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_array_list);


        //referencing my recyclerview
        recycler = (RecyclerView) findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        //adapter
        MyArrayAdapter adapter = new MyArrayAdapter(this,auctions);
        recycler.setAdapter(adapter);
    }

}